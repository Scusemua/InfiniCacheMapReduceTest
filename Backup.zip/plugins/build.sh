go build --buildmode=plugin -o srtr_service.so srtr_service.go
go build --buildmode=plugin -o srtm_service.so srtm_service.go
